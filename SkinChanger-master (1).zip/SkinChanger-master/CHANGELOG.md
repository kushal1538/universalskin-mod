# Changelog

## 0.6.2
- Update to forge 1.20.6-50.1.0

## 0.6.1
- Added translation files for ES-MX
- Update to forge 1.20.2-48.1.0

## 0.6.0
- Update to forge 1.20-46.0.14

## 0.5.0
- Update to forge 1.19-41.1.0

## 0.4.0
- Update to forge 1.18-38.0.17

## 0.3.0
- Update to forge 1.17.1-37.1.1

## 0.2.2
- Update to forge 1.16.5-36.1.0
- Try to use Minecraft skin if no cache skin is found

## 0.2.1
- Fixed runtime incompatibility with 1.16.3
- Fixed possible null pointer exception on PlayerModel

## 0.2.0
- Update to forge 1.16.4-35.0.15

## 0.1.0
- Update to forge 1.15.2-31.2.0

## 0.1-beta.3
- Update mod description and added logo
- Fixed issue when an online server resolves wrongly the player head
- Fixed issue for player head not being loaded of the player is not online

## 0.1-beta.2
- Removed unused config file
- Added support for skull rendering
- Added support for tab overlay skin rendering

## 0.1-beta.1
- Skin change support
- Cape change support
- Admin permissions to change users skins
