package me.edoren.skin_changer.common;

public class Constants {
    public static final String MOD_ID = "skin_changer";
}
