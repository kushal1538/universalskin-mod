package me.edoren.skin_changer.server.providers;

public interface ISkinProvider {
    byte[] getSkin(String playerName);
}
