---
name: Feature request
about: Suggest an idea for a new feature / change to the mod
title: ""
labels: pending action, optional
assignees: ''

---

**Brief Summary:**
A very brief summary of the feature

**Usage:**
1. I do this thing...
2. I do next thing...
3. ...
4. Thing is done

**Justification:**
Why should this be done? How will it work in the mod? Is it worth adding to the mod?

**Steps:**
 - [ ] Leave this blank if you don't know what you're doing
