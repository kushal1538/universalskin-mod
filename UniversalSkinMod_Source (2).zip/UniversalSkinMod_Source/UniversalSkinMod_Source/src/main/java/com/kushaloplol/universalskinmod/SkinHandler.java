package com.kushaloplol.universalskinmod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.util.ResourceLocation;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class SkinHandler {
    public static ResourceLocation overriddenSkin;

    public static void reloadSkin() {
        try {
            File skinFile = new File(Minecraft.getMinecraft().mcDataDir, "config/UniversalSkinMod/skin.png");
            if (!skinFile.exists()) {
                System.err.println("[UniversalSkinMod] skin.png not found in config folder.");
                overriddenSkin = null;
                return;
            }

            BufferedImage skinImage = ImageIO.read(skinFile);
            DynamicTexture dynamicTexture = new DynamicTexture(skinImage);
            overriddenSkin = Minecraft.getMinecraft().getTextureManager()
                    .getDynamicTextureLocation("custom_skin", dynamicTexture);

            System.out.println("[UniversalSkinMod] Successfully reloaded custom skin!");
        } catch (IOException e) {
            System.err.println("[UniversalSkinMod] Failed to load custom skin!");
            e.printStackTrace();
        }
    }
}