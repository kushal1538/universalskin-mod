package com.kushaloplol.universalskinmod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.util.ResourceLocation;

public class SkinOverrideRenderer extends RenderPlayer {

    public SkinOverrideRenderer(RenderManager renderManager) {
        super(renderManager);
    }

    @Override
    protected ResourceLocation getEntityTexture(AbstractClientPlayer player) {
        if (UniversalSkinMod.isEnabled &&
                !player.getUniqueID().equals(Minecraft.getMinecraft().thePlayer.getUniqueID()) &&
                SkinHandler.overriddenSkin != null) {
            return SkinHandler.overriddenSkin;
        }
        return super.getEntityTexture(player);
    }
}