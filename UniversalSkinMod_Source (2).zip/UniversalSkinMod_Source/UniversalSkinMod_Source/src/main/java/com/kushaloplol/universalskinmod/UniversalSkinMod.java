package com.kushaloplol.universalskinmod;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.Mod.Instance;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import org.lwjgl.input.Keyboard;

import java.io.File;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

@Mod(modid = UniversalSkinMod.MODID, name = UniversalSkinMod.NAME, version = UniversalSkinMod.VERSION)
public class UniversalSkinMod {

    public static final String MODID = "universalskinmod";
    public static final String NAME = "Universal Skin Mod";
    public static final String VERSION = "1.0";

    @Instance
    public static UniversalSkinMod instance;

    public static KeyBinding toggleSkinKey;
    public static KeyBinding reloadSkinKey;

    public static boolean isEnabled = true;

    @EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        File configDir = new File(event.getModConfigurationDirectory(), "UniversalSkinMod");
        if (!configDir.exists()) configDir.mkdirs();
    }

    @EventHandler
    public void init(FMLInitializationEvent event) {
        toggleSkinKey = new KeyBinding("Toggle Skin Override", Keyboard.KEY_U, "Universal Skin Mod");
        reloadSkinKey = new KeyBinding("Reload Skin", Keyboard.KEY_R, "Universal Skin Mod");
        ClientRegistry.registerKeyBinding(toggleSkinKey);
        ClientRegistry.registerKeyBinding(reloadSkinKey);

        FMLCommonHandler.instance().bus().register(this);

        // Safe injection of custom renderers using reflection
        RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
        Map<String, RenderPlayer> originalMap = renderManager.getSkinMap();
        Map<String, RenderPlayer> modifiedMap = new HashMap<>();

        for (Map.Entry<String, RenderPlayer> entry : originalMap.entrySet()) {
            modifiedMap.put(entry.getKey(), new SkinOverrideRenderer(renderManager));
        }

        try {
            Field skinMapField = RenderManager.class.getDeclaredField("skinMap");
            skinMapField.setAccessible(true);
            skinMapField.set(renderManager, modifiedMap);
            System.out.println("[UniversalSkinMod] Successfully injected custom skin renderers.");
        } catch (Exception e) {
            System.err.println("[UniversalSkinMod] Failed to replace skin renderers!");
            e.printStackTrace();
        }
    }

    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event) {
        if (toggleSkinKey.isPressed()) {
            isEnabled = !isEnabled;
        } else if (reloadSkinKey.isPressed()) {
            SkinHandler.reloadSkin();
        }
    }
}